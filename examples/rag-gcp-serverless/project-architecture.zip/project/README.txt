project - cloud architecture review

report.md        The full review: choices, why each service was chosen, blockers, diagrams with
                 explanations, web sources.
report.html      The same report as a web page. Open it in a browser; it draws the diagrams
                 (needs an internet connection for the Mermaid library).
diagrams/        Mermaid source for each diagram. Paste into https://mermaid.live to edit.
images/          SVG images of every diagram.
                 npm install -g @mermaid-js/mermaid-cli and render_diagram.py to create them.
data/            The evidence, service placements and web sources the report is based on.

Cloud: gcp   Compute model: serverless

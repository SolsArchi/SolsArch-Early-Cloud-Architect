# Cloud Architecture Review: project

**Cloud:** GCP | **Compute model:** serverless | **Evidence:** 9 items from `ast_scanner.py` | **Date:** 2026-10-17

## 1. Summary
This is a small Python 3.12 FastAPI chat service that streams answers over server-sent events, calls the OpenAI API through LangChain, and keeps embeddings in Chroma. The recommended target on GCP serverless is API Gateway in front of Cloud Functions for ordinary requests and Cloud Run for the streaming traffic, with Cloud SQL for PostgreSQL with pgvector as the vector store and Secret Manager for keys. The main risk is the nginx proxy (SEC-004), which would drop streams, and the time and preview limits of streaming through API Gateway. Fix the proxy settings first, then confirm the streaming limits.

## 2. Your choices and why they shape the design
- **Cloud: GCP.** Every service below is a Google Cloud product, so the entry point, compute, data and secrets all stay inside one project and one IAM model.
- **Compute model: serverless.** Functions scale to zero and need no servers, but they have request time limits and are a poor fit for long streams, so the streaming route moves to Cloud Run, which still scales to zero.

## 3. What the codebase tells us
- Python source (E009) with a `python:3.12` Dockerfile (E001).
- FastAPI web framework (E002).
- OpenAI API (E003) and LangChain (E005) for language model calls.
- Chroma vector store (E004).
- Streaming: `sse-starlette` (E006) and a `StreamingResponse` with `text/event-stream` in `app/chat.py` line 4 (E007).
- An nginx reverse proxy with `proxy_pass` in `deploy/nginx.conf` line 3 (E008).

## 4. Service decisions
One row for every placement in `placements.json`, in the same order and with the same ids.

| ID | Service | Category | Evidence | Confidence | Why this service | Alternative considered |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| P01 | Cloud Functions | Backend compute | E002 | Confirmed | Runs the FastAPI API without managing servers. | An always-on container service |
| P02 | API Gateway | Public entry point | E001, E002 | Inferred | Gives the internet one managed door to private compute. | A load balancer |
| P03 | Cloud SQL for PostgreSQL with pgvector | Vector store | E004 | Inferred | Keeps embeddings in one managed database instead of another system. | A dedicated vector database such as Qdrant Cloud |
| P04 | Secret Manager | Secrets management | E003, E005 | Inferred | Holds the model provider keys outside code and images. | Parameter store for non-rotating values |
| P05 | Cloud Run (WebSocket support) | Realtime connections | E006, E007 | Inferred | Holds long streaming connections that functions handle poorly. | An always-on container service |

### 4.1 Why each service

### P01 Cloud Functions
The codebase declares FastAPI in `requirements.txt` (E002), so it serves an HTTP API, and you chose serverless. Cloud Functions runs that API with no servers to manage and scales to zero, which is why it is the default compute here. The alternative considered was an always-on container service, which suits long requests and background work better. The caveat from the placement rules is that streaming responses run into function time limits. Source R001 shows second generation HTTP functions allow long requests, but streamed responses have a smaller size cap, and WebSockets are not mentioned, so streaming stays on Cloud Run (P05). The Google Cloud docs now brand second generation functions as Cloud Run functions, so check which generation you deploy.

### P02 API Gateway
Traffic from the internet must reach private compute through a managed entry point and never directly (SEC-001). The Dockerfile (E001) and FastAPI framework (E002) show a network-facing service, so API Gateway is placed in front. It also replaces the nginx proxy for routing. A load balancer was considered and is the right choice if you move to always-on containers. Source R002 shows request and response bodies are capped at 32MB and that streaming through the gateway (server-sent events and WebSockets) is in Public Preview and needs a gateway created with streaming enabled. Treat that as a risk for the chat route and confirm it before launch.

### P03 Cloud SQL for PostgreSQL with pgvector
The repo lists `chromadb` in `requirements.txt` line 3 (E004), a vector store library. For small and medium corpora, pgvector inside Cloud SQL for PostgreSQL avoids running one more data system and gives a managed, backed-up database. A dedicated vector database such as Qdrant Cloud was considered for large corpora. Source R003 confirms pgvector is supported on Cloud SQL for PostgreSQL and is enabled with `CREATE EXTENSION`. The corpus size is not determined from the repo, so this is an inference, and moving off Chroma needs a code change.

### P04 Secret Manager
The code uses the OpenAI API (E003) and LangChain (E005), which need provider keys. Keys belong in Secret Manager and are injected at runtime, never kept in code or images (SEC-005). Parameter store for non-rotating values was considered but Secret Manager handles rotation and access control. Source R004 shows each secret version holds up to 64 KiB, which is ample for API keys. No hardcoded secrets were found by the scanner.

### P05 Cloud Run (WebSocket support)
The repo has `sse-starlette` (E006) and a streaming response in `app/chat.py` line 4 (E007). Plain functions have request time limits, so Cloud Run holds the streaming connections while still scaling to zero. An always-on container service was considered. Source R005 shows WebSockets need no extra configuration, but each stream counts as a request bound by the service timeout (default 5 minutes, maximum 60 minutes), clients must reconnect, and session affinity is best effort. Set the timeout to the longest stream you expect and keep any shared state outside the instance.

## 5. Pre-deployment security blockers
| Rule | Finding | Evidence | Fix |
| :--- | :--- | :--- | :--- |
| SEC-004 | The nginx config proxies to the app with no `proxy_buffering off` and no long `proxy_read_timeout`, while the app streams server-sent events. Confirmed by reading `deploy/nginx.conf`. | E006, E007, E008, deploy/nginx.conf:3 | Add `proxy_buffering off;` and `proxy_read_timeout` of at least 300s on the streaming route, or drop nginx in favour of API Gateway and set the Cloud Run timeout to match. |

SEC-001 to SEC-003 and SEC-005 were checked and nothing fired. SEC-001 holds in this design because all traffic passes through API Gateway before compute.

## 6. Diagrams
Every diagram is followed by an explanation of at least 40 words: what the boxes and arrows are, which services appear and why, and how to read the main flow.

### 6.1 Cloud infrastructure
```mermaid
flowchart TD
  user["Users (Browser)"]
  subgraph gcpb["Google Cloud project"]
    gw["API Gateway"]
    fn["Cloud Functions (FastAPI API)"]
    run["Cloud Run (streaming and WebSocket)"]
    sm["Secret Manager"]
    db[("Cloud SQL for PostgreSQL with pgvector")]
  end
  llm["OpenAI API (external)"]
  user -->|"HTTPS:443"| gw
  gw -->|"HTTPS:443"| fn
  gw -->|"HTTPS:443"| run
  fn -->|"PostgreSQL:5432 TLS"| db
  run -->|"PostgreSQL:5432 TLS"| db
  fn -->|"HTTPS:443"| sm
  run -->|"HTTPS:443"| sm
  fn -->|"HTTPS:443"| llm
  run -->|"HTTPS:443"| llm
  classDef gcp fill:#4285F4,stroke:#1A4DA1,color:#FFFFFF
  classDef user fill:#FFFFFF,stroke:#14202B,color:#000000
  classDef external fill:#F3F3F3,stroke:#8A8A8A,color:#000000
  class gw,fn,run,sm,db gcp
  class user user
  class llm external
```

This diagram shows the Google Cloud project. Users reach API Gateway over HTTPS, the single public door (SEC-001). The gateway routes ordinary requests to Cloud Functions (P01) and streaming traffic to Cloud Run (P05). Both talk to Cloud SQL with pgvector (P03) over TLS, read keys from Secret Manager (P04), and call the external OpenAI API. Blue boxes are Google services, grey is external.

### 6.2 C4 container view
```mermaid
C4Container
  title Container diagram
  Person(user, "End user", "Browser")
  System_Boundary(sys, "Chat application") {
    Container(gw, "API Gateway", "Google API Gateway", "Single public entry point")
    Container(api, "API", "FastAPI on Cloud Functions", "Request and response endpoints")
    Container(stream, "Streaming service", "FastAPI on Cloud Run", "Holds SSE and WebSocket connections")
    ContainerDb(db, "Vector store", "Cloud SQL for PostgreSQL with pgvector", "Embeddings and metadata")
    Container(sec, "Secrets", "Secret Manager", "API keys")
  }
  System_Ext(llm, "LLM provider", "OpenAI API")
  Rel(user, gw, "Uses", "HTTPS")
  Rel(gw, api, "Routes requests to", "HTTPS")
  Rel(gw, stream, "Routes streams to", "HTTPS")
  Rel(api, db, "Queries", "SQL")
  Rel(stream, db, "Queries", "SQL")
  Rel(api, sec, "Reads keys from", "HTTPS")
  Rel(stream, llm, "Streams prompts to", "HTTPS")
```

This C4 container view names the deployable units of the chat application. The user calls the gateway, which fronts the API on Cloud Functions and the streaming service on Cloud Run. Both read the vector store in Cloud SQL, the API fetches keys from Secret Manager, and the streaming service sends prompts to the external LLM provider. Arrows point from caller to callee with the protocol.

### 6.3 Runtime sequence
```mermaid
sequenceDiagram
  participant C as Client
  participant G as API Gateway
  participant S as Streaming service
  participant V as Vector Store
  participant L as LLM Provider
  C->>G: POST /chat with question
  G->>S: Forward over HTTPS
  S->>V: Similarity search (top k)
  V-->>S: Matching chunks
  S->>L: Prompt with chunks (stream)
  loop token stream
    L-->>S: Token
    S-->>C: SSE event
  end
  S-->>C: Stream end
```

This sequence follows one chat question, the retrieval augmented pattern, since the repo has a vector store and an LLM. The client posts a question through the gateway to the streaming service on Cloud Run, which searches the vector store, sends the matching chunks to the LLM and relays each token back as a server-sent event until the stream ends. Streaming needs long timeouts on every hop (SEC-004).

### 6.4 Code topology
```mermaid
flowchart LR
  subgraph repo["Repository"]
    app["app/chat.py (FastAPI)"]
    dock["Dockerfile (python 3.12)"]
    req["requirements.txt"]
    ngx["deploy/nginx.conf"]
  end
  subgraph rt["Cloud runtime"]
    fn["Cloud Functions"]
    run["Cloud Run"]
    gw["API Gateway"]
  end
  app -->|"source code"| fn
  dock -->|"container image"| run
  req -->|"dependencies"| run
  ngx -->|"replaced by"| gw
```

This diagram maps the repository to the cloud runtime. The application code in `app/chat.py` becomes the function on Cloud Functions, the Dockerfile and requirements build the container image that runs on Cloud Run, and the nginx config is replaced by API Gateway for routing. It helps you see which folder deploys to which service and what is retired.

## 7. Web verification
Each service was checked against current vendor documentation. Cite the sources by id.

| Service | Source | What it confirmed |
| :--- | :--- | :--- |
| Cloud Functions | R001 | Second generation HTTP functions allow long requests; streamed responses are capped at 10MB; WebSockets not mentioned. |
| API Gateway | R002 | 32MB body cap; streaming and WebSockets are Public Preview and need streaming enabled on the gateway. |
| Cloud SQL for PostgreSQL with pgvector | R003 | pgvector is supported and enabled with `CREATE EXTENSION`. |
| Secret Manager | R004 | 64 KiB per secret version; modest write rate per secret. |
| Cloud Run (WebSocket support) | R005 | WebSockets work with no setup; timeout default 5 minutes, maximum 60; best effort affinity. |

Searches for deprecation notices found none for these services; no source showed a service unavailable or deprecated.

## 8. Assumptions and open questions
- Region, traffic, budget and compliance needs are not determined from the repo.
- Corpus size for the vector store is not determined from the repo, so pgvector is an assumption.
- API Gateway streaming is in Public Preview; confirm it is acceptable, or put Cloud Run behind a load balancer instead.
- The Chroma data would need migrating to PostgreSQL; the code change is not designed here.

## 9. Decisions recorded
| ADR | Component | Decision | Status |
| :--- | :--- | :--- | :--- |
| ADR-001 | Backend compute | Cloud Functions for the FastAPI API | PROPOSED |
| ADR-002 | Realtime connections | Cloud Run for SSE and WebSocket traffic | PROPOSED |
| ADR-003 | Vector store | Cloud SQL for PostgreSQL with pgvector replaces Chroma | PROPOSED |

Status values: PROPOSED, APPROVED, REJECTED, SUPERSEDED.

## 10. Self-check before delivering
- [x] Every row in `placements.json` appears in section 4 and has its own subsection
- [x] Every Mermaid block passed `diagram_sanitizer.py` and has an explanation
- [x] Section 7 cites logged sources, or says web verification was not performed
- [x] `verify_report.py` exits 0
- [x] `package_outputs.py` wrote the zip

---
Next step: the full SolsArch pipeline generates the Terraform, Ansible, cost model and deep security review for this architecture.

solsarch-mvp - cloud architecture review

report.md        The full review: choices, why each service was chosen, blockers, diagrams with
                 explanations, web sources.
report.html      The same report as a web page. Open it in a browser; it draws the diagrams
                 (needs an internet connection for the Mermaid library).
diagrams/        Mermaid source for each diagram. Paste into https://mermaid.live to edit.
images/          architecture-icons.svg (the architecture with a service icon on every box) and an SVG of every Mermaid diagram.
data/            The evidence, service placements and web sources the report is based on.

Cloud: aws   Compute model: server

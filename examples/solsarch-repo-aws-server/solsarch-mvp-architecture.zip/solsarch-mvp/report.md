# Cloud Architecture Review: SolsArch-MVP

**Cloud:** AWS | **Compute model:** server-based | **Evidence:** 43 items from `ast_scanner.py` | **Date:** 2026-10-17

## 1. Summary
SolsArch is a FastAPI and LangGraph backend with a Next.js frontend that calls LLM providers and keeps state in local SQLite files (E001, E021, E003, E020). The recommended AWS target is two Amazon ECS on AWS Fargate services behind a public Application Load Balancer, with Aurora PostgreSQL for data, Secrets Manager for keys and a NAT Gateway for outbound LLM calls. The main risk is SEC-003: the SQLite files cannot be shared by several tasks and are lost on managed compute without a volume. Move the data to Aurora first, and raise the load balancer idle timeout for the WebSocket route before launch.

## 2. Your choices and why they shape the design
- **Cloud: AWS.** The user asked for AWS, so every service below is an AWS service and the diagrams use the AWS palette.
- **Compute model: server-based.** This was assumed because it was not stated; the question "Should it be server-based (always-on containers or machines) or serverless (functions and scale-to-zero services)?" would normally be asked. Always-on Fargate tasks suit long pipeline runs and WebSocket streaming, and avoid function time limits.

## 3. What the codebase tells us
- Python and TypeScript code: 246 Python and 147 TypeScript files (E041, E042).
- Frameworks: FastAPI with Uvicorn (E001, E002) and Next.js with React (E021, E022).
- AI use: LangGraph, LangChain, OpenAI and Anthropic SDKs (E003 to E009).
- Data: SQLite in the backend (E020, E010, E023) and PostgreSQL drivers in a sample app (E018).
- Containers: Dockerfiles for backend and frontend and a Compose file with persistent volumes and a Caddy proxy (E024, E037, E028, E029, E031).
- Streaming: a WebSocket route at `/ws/runs/{run_id}` (E019).

## 4. Service decisions
| ID | Service | Category | Evidence | Confidence | Why this service | Alternative considered |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| P01 | Amazon ECS on AWS Fargate | Backend compute | E001, E015 | Confirmed | Runs the FastAPI container without managing servers | Serverless option for spiky traffic |
| P02 | Amazon ECS on AWS Fargate | Frontend compute | E021 | Confirmed | Next.js needs a Node.js runtime for server rendering | A managed frontend host such as Vercel |
| P03 | Application Load Balancer | Public entry point | E001, E013, E015, E021 | Inferred | Single public entry so compute stays private (SEC-001) | An API gateway for per-route auth |
| P04 | Amazon Aurora PostgreSQL | Relational database | E010, E017, E018, E020 | Confirmed | Shared managed database replaces local SQLite | A serverless database tier |
| P05 | AWS Secrets Manager | Secrets management | E003, E004, E005, E006 | Inferred | Keeps LLM keys out of code and images (SEC-005) | Parameter store |
| P06 | NAT Gateway | Outbound internet access | E003, E004, E005, E006 | Inferred | Private tasks reach LLM APIs without public IPs | Private endpoints where offered |

### 4.1 Why each service
### P01 Amazon ECS on AWS Fargate
The backend is a FastAPI app declared in `requirements.txt` (E001) with a sample app that also uses FastAPI (E015), and it ships as a container through `docker/backend.Dockerfile`. Fargate runs that container without servers to patch, which fits the server-based choice and the long-running pipeline and WebSocket sessions. The alternative was the serverless option for spiky traffic and short requests. Caveat: the load balancer idle timeout must be raised for the streaming route (SEC-004). Vendor docs (R001, R002) say Fargate has per-region vCPU and launch-rate quotas, so check quotas before scaling; use platform version 1.4.0 or LATEST because 1.3.0 is retired.

### P02 Amazon ECS on AWS Fargate
The frontend uses Next.js (E021), which needs a Node.js runtime for server rendering, and `docker/frontend.Dockerfile` already packages it. A second Fargate service in the same cluster runs it with its own task size, so the frontend scales apart from the backend. The alternative was a managed frontend host such as Vercel, which would split hosting across two vendors. No extra caveat beyond the quota notes in P01.

### P03 Application Load Balancer
Internet traffic must reach private compute only through a managed entry point (SEC-001). The Compose setup uses Caddy as a reverse proxy (E031) and publishes ports 80 and 443 (E032, E033); on AWS the Application Load Balancer replaces that role for the FastAPI and Next.js containers (E001, E021, E013, E015). Path rules send `/api/*` and the WebSocket path to the backend and everything else to the frontend. The alternative was an API gateway if per-route auth and throttling are needed. Docs (R003, R004) show the idle timeout defaults to 60 seconds and is configurable, and at least two Availability Zone subnets are needed.

### P04 Amazon Aurora PostgreSQL
The backend stores data in a local SQLite file (E020, plus E010 and E023) and a sample app declares SQLAlchemy and PostgreSQL drivers (E017, E018). A local file cannot be shared by several tasks and is lost on managed compute without a mounted volume (SEC-003). Aurora PostgreSQL gives backups, failover and shared access. The alternative was a serverless database tier for uneven load. Caveat: the data must be migrated and the code ported from sqlite3 to PostgreSQL. Docs (R005, R006) show quotas far above this app's size, and older major versions leave standard support, so pick a current engine version.

### P05 AWS Secrets Manager
The code uses LangGraph, LangChain, the OpenAI and Anthropic SDKs (E003, E004, E005, E006) which need provider keys, and the Compose file keeps an encryption key on a volume. Secrets Manager injects them into tasks at runtime (SEC-005). The alternative was Parameter Store for values that do not rotate. Docs (R007, R008) show per-region API quotas and no deprecation, so cache values at start-up and retry with backoff.

### P06 NAT Gateway
Tasks in private subnets must still call LLM provider APIs over HTTPS (E003, E004, E005, E006). A NAT Gateway gives outbound access without exposing the tasks. The alternative was private endpoints where the provider offers them. Docs (R009, R010) say a NAT gateway lives in one Availability Zone, so use one per zone for resilience, and a regional NAT gateway option now exists.

## 5. Pre-deployment security blockers
| Rule | Finding | Evidence | Fix |
| :--- | :--- | :--- | :--- |
| SEC-003 | SQLite file opened by the backend; Compose mounts a local data volume. Confirmed in `Backend/modules/database.py:65` and `docker/docker-compose.yml:40` | E020, E029, E010, E023 | Move state to Aurora PostgreSQL; multi-task scaling needs a shared database |
| SEC-004 | A WebSocket route exists at `Backend/api/websocket_stream.py:70` and will sit behind a load balancer whose idle timeout defaults to 60 seconds (R004). Design-level finding, not a scanner hit. Also, `docker/Caddyfile` routes only `/api/*` to the backend, so the WebSocket path needs its own ALB rule | E019 | Raise ALB idle timeout to at least 300 seconds and route the WebSocket path to the backend target group |

Checked and not reported: SEC-001 (the design puts the ALB in front of private tasks), SEC-002 (no open database CIDR found) and SEC-005 (scanner hits E011 and E012 at `Agents/Agent11(Security check)/security/prompts.py:205` and `:295` are example text inside an LLM prompt, not real IAM statements, so they were dismissed after reading the lines).

## 6. Diagrams
### 6.1 Cloud infrastructure
![Architecture with service icons](images/architecture-icons.svg)

The picture above is made automatically when you package the report (keep the line as it is). It shows every chosen service with an icon. The editable Mermaid version follows.

```mermaid
flowchart TD
  user["Users (Browser)"]
  subgraph vpc["VPC 10.0.0.0/16"]
    subgraph pub["Public subnets (2 AZ)"]
      alb["Application Load Balancer"]
      nat["NAT Gateway"]
    end
    subgraph app["Private app subnets (2 AZ)"]
      web["Next.js frontend (ECS Fargate)"]
      api["FastAPI backend (ECS Fargate)"]
    end
    subgraph data["Isolated data subnets (2 AZ)"]
      db[("Aurora PostgreSQL")]
    end
  end
  sm["AWS Secrets Manager"]
  llm["LLM APIs (OpenAI, Anthropic, external)"]
  user -->|"HTTPS:443"| alb
  alb -->|"HTTP:3000"| web
  alb -->|"HTTP:8000 and WebSocket"| api
  api -->|"PostgreSQL:5432 TLS"| db
  api -->|"HTTPS:443 secrets fetch"| sm
  api -->|"HTTPS:443 via NAT"| nat
  nat -->|"HTTPS:443"| llm
  classDef aws fill:#FF9900,stroke:#232F3E,color:#000000
  classDef user fill:#FFFFFF,stroke:#14202B,color:#000000
  classDef external fill:#F3F3F3,stroke:#8A8A8A,color:#000000
  class alb,nat,web,api,db,sm aws
  class user user
  class llm external
```

Users reach the Application Load Balancer over HTTPS in the public subnets. It forwards to the Next.js and FastAPI Fargate services in private subnets, so compute is never directly exposed. The backend reads and writes Aurora PostgreSQL in isolated data subnets, fetches keys from Secrets Manager and reaches the LLM providers through the NAT Gateway. Each arrow is labelled with its protocol and port.

### 6.2 C4 container view
```mermaid
C4Container
  title Container diagram
  Person(user, "End user", "Browser")
  System_Boundary(sys, "SolsArch on AWS") {
    Container(web, "Web frontend", "Next.js on ECS Fargate", "Serves the UI")
    Container(api, "API", "FastAPI on ECS Fargate", "Pipeline orchestration, auth, WebSocket streaming")
    ContainerDb(db, "Database", "Aurora PostgreSQL", "Relational data replacing SQLite")
  }
  System_Ext(llm, "LLM providers", "OpenAI and Anthropic APIs")
  System_Ext(sm, "Secrets Manager", "API keys and encryption key")
  Rel(user, web, "Uses", "HTTPS via ALB")
  Rel(web, api, "Calls", "HTTPS/JSON")
  Rel(api, db, "Reads and writes", "SQL")
  Rel(api, llm, "Sends prompts", "HTTPS via NAT")
  Rel(api, sm, "Reads secrets", "HTTPS")
```

The C4 container view shows the deployable units inside the system boundary: the Next.js web frontend, the FastAPI API and the Aurora PostgreSQL database. Outside the boundary are the LLM providers and Secrets Manager. The user talks to the frontend, which calls the API, and the API stores data and calls the external services. It maps to the Fargate services, Aurora, the NAT route and Secrets Manager in the infrastructure diagram.

### 6.3 Runtime sequence
```mermaid
sequenceDiagram
  participant C as Client
  participant L as Load Balancer
  participant A as API
  participant D as Database
  participant M as LLM Provider
  C->>L: POST /api/runs over HTTPS
  L->>A: Route to healthy task
  A->>D: Insert run record
  D-->>A: Ok
  A-->>C: 202 with run id
  C->>L: Open WebSocket /ws/runs/id
  L->>A: Upgrade to WebSocket
  loop pipeline progress
    A->>M: Prompt over HTTPS via NAT
    M-->>A: Completion
    A->>D: Save agent result
    A-->>C: Progress event
  end
  A-->>C: Run complete
```

This sequence follows a pipeline run. The client starts a run through the load balancer, the API records it in the database and answers with a run id, and the client then opens a WebSocket for progress. While the pipeline runs, the API calls the LLM provider, saves each result and pushes progress events to the client. The long-lived WebSocket is why the load balancer idle timeout matters (SEC-004).

### 6.4 Code topology
```mermaid
flowchart LR
  subgraph repo["Repository"]
    fe["Frontend/ (Next.js)"]
    be["Backend/ and Agents/ (FastAPI, LangGraph)"]
    infra["docker/ (Compose, Caddy)"]
  end
  subgraph rt["AWS runtime"]
    web["Frontend service (Fargate)"]
    api["Backend service (Fargate)"]
    entry["Application Load Balancer"]
  end
  fe -->|"container image"| web
  be -->|"container image"| api
  infra -->|"deploy config replaced by ALB rules"| entry
```

The code topology maps repository folders to runtime pieces. The frontend folder builds into the frontend Fargate service image, and the backend and agents folders build into the backend service image. The Compose and Caddy files under docker are not deployed as is; their reverse proxy role is replaced by Application Load Balancer rules, which is why that arrow points to the load balancer.

## 7. Web verification
Each service was checked against current vendor documentation. Cite the sources by id.

| Service | Source | What it confirmed |
| :--- | :--- | :--- |
| Amazon ECS on AWS Fargate | R001 | Per-region vCPU quotas and launch-rate limits that can be raised |
| Amazon ECS on AWS Fargate | R002 | Runs containers without servers; ALB targets must be ip type; platform 1.3.0 retired |
| Application Load Balancer | R003 | Adjustable per-region quotas for load balancers and listeners |
| Application Load Balancer | R004 | Idle timeout defaults to 60 seconds and is configurable; two zones needed |
| Amazon Aurora PostgreSQL | R005 | Quotas and size ceilings far above this app's needs |
| Amazon Aurora PostgreSQL | R006 | Older major versions leave standard support; pick a current one |
| AWS Secrets Manager | R007 | Per-region API and version quotas; retry with backoff |
| AWS Secrets Manager | R008 | Only feature additions listed, no deprecation |
| NAT Gateway | R009 | Single-zone resource, one per zone advised |
| NAT Gateway | R010 | Regional NAT gateway option added; zonal not deprecated |

## 8. Assumptions and open questions
- Compute model assumed server-based; the user did not state it. The question still to ask: "Should it be server-based (always-on containers or machines) or serverless (functions and scale-to-zero services)?"
- Region, traffic volume, data size and compliance needs are not determined from the repo.
- Starting sizes: about 0.5 vCPU and 1 GB for the Python API, about 1 vCPU and 2 GB for Next.js server rendering. Measure under load before production.
- The sample app under `Agents/simulate_app` is the only source of the PostgreSQL evidence (E018); the main backend still uses SQLite, so a code port is needed.
- Results folders and the secrets key file are on volumes in Compose (E029, E030); their AWS equivalent (object storage or shared file system) is not determined from the repo.

## 9. Decisions recorded
| ADR | Component | Decision | Status |
| :--- | :--- | :--- | :--- |
| ADR-001 | Compute | Run API and web frontend on Amazon ECS on AWS Fargate | PROPOSED |
| ADR-002 | Entry point | Public Application Load Balancer in front of private Fargate tasks | PROPOSED |
| ADR-003 | Database | Migrate SQLite to Aurora PostgreSQL | PROPOSED |
| ADR-004 | Secrets | Keep LLM keys and encryption key in AWS Secrets Manager | PROPOSED |

## 10. Self-check before delivering
- [x] Every row in `placements.json` appears in section 4 and has its own subsection
- [x] Every Mermaid block passed `diagram_sanitizer.py` and has an explanation
- [x] Section 7 cites logged sources, or says web verification was not performed

---
Next step: the full SolsArch pipeline generates the Terraform, Ansible, cost model and deep security review for this architecture.
